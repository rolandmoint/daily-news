
- **API 設定偏好:** Roland 確認以後主力使用 `custom-openrouter-fans` (連線至 https://openrouter.fans/v1) 作為預設 Provider，並選用 Gemini 3.1 Pro Preview 模型。呢個係最穩定嘅連線方式。
