# USER.md - About Your Human

- **Name:** Roland
- **What to call them:** 大佬 或 老友 (Roland)
- **Timezone:** Asia/Shanghai
- **Notes:** 
  - 主要郵箱：rickmacau721@gmail.com
  - 太太 (Vic / bay / 肥多 / Rva) 郵箱：portugal.lx.mo@gmail.com
  - Google Calendar 創建活動時，必須用系統帳號 (roland.mo.int@gmail.com) 做主理人，再加 Roland / Vic 做參與者。